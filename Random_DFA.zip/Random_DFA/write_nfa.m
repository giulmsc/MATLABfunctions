function write_nfa(filename, DFA, grouped_finals)
    fid = fopen(filename, 'w');
    if fid == -1
        error('Impossibile aprire il file per la scrittura.');
    end

    % Numero di stati
    fprintf(fid, '%% State number\n');
    fprintf(fid, '%d\n\n', size(DFA.states, 1));

    % Alfabeto
    fprintf(fid, '%% Alphabet\n');
    fprintf(fid, '%s ', DFA.alphabet{:});
    fprintf(fid, '\n\n');

    % Eventi osservabili
    fprintf(fid, '%% Observable event\n');
    if isempty(DFA.obs_events)
        fprintf(fid, '-\n\n');
    else
        fprintf(fid, '%s ', DFA.obs_events{:});
        fprintf(fid, '\n\n');
    end

    % Eventi non osservabili
    fprintf(fid, '%% Unobservable event\n');
    if strcmp(DFA.unobs_events,'No unobservable events')
        fprintf(fid, '-\n\n');
    else
        fprintf(fid, '%s ', DFA.unobs_events{:});
        fprintf(fid, '\n\n');
    end

    % Eventi di guasto
    fprintf(fid, '%% Fault event\n');
    if strcmp(DFA.fault_events,'No fault events')
        fprintf(fid, '-\n\n');
    else
        fprintf(fid, '%s ', DFA.fault_events{:});
        fprintf(fid, '\n\n');
    end

    % Transizioni
    fprintf(fid, '%% Transitions\n');
    for i = 1:size(DFA.transitions, 1)
        from_id = DFA.state_map(DFA.transitions{i, 1}) - 1;
        to_id = DFA.state_map(DFA.transitions{i, 3}) - 1;
        event = DFA.transitions{i, 2};
        fprintf(fid, '%d %s %d\n', from_id, event, to_id);
    end
    fprintf(fid, '\n');

    % Stato iniziale
    fprintf(fid, '%% Initial states\n');
    init_states = DFA.initialStates;
    
    if isnumeric(init_states)
        fprintf(fid, '%s \n\n', sprintf('%d ',init_states - 1));  % 0-based
    elseif iscell(init_states)
        for i = 1:numel(init_states)
            label = init_states{i};
            idx = DFA.state_map(label) - 1;
            fprintf(fid, '%d \n\n',sprintf('%d ', idx));
        end
        fprintf(fid, '\n\n');
    end

    
    % Stati finali
    fprintf(fid, '%% Final states \n');
 
    final_states = DFA.finalStates;
    
    
    
    if isempty(final_states)
        fprintf(fid, '-\n\n');

    elseif isnumeric(final_states)
        % Un singolo gruppo numerico
        final_indices = sort(final_states) - 1;
     
        fprintf(fid, '%s\n\n', sprintf('%d ', final_indices));

        elseif iscell(final_states) && isnumeric(final_states{1})
            % Più gruppi: final_states = {{...}, {...}, ...}
            if grouped_finals
                for i = 1:numel(final_states)
                    
                    group = final_states{i};
        
                    if iscell(group)
                        group_indices = cellfun(@(s) get_index(DFA, s), group) - 1;
                    else
                        group_indices = group - 1;  % se già numerico
                    end
                    fprintf(fid, '%s\n', sprintf('%d ', sort(group_indices)));
                end
                fprintf(fid, '\n');
            else
                % Unisce tutto in un'unica riga
        
                all_finals = [final_states{:}];

                if iscell(all_finals)
                    all_indices = cellfun(@(s) get_index(DFA, s), all_finals) - 1;
                else
                    all_indices = all_finals - 1;
                end
                fprintf(fid, '%s\n\n', sprintf('%d ', sort(unique(all_indices))));
            end
        end
    fclose(fid);
    fprintf('Automa salvato in formato strutturato nel file "%s"\n', filename);
end

function idx = get_index(DFA, s)
    if ischar(s)
        idx = DFA.state_map(s);
    elseif isstring(s)
        idx = DFA.state_map(char(s));  % converte string → char
    else
        idx = s;  % già numerico
    end
end