%% FUNCTION: main_bisimulation_generalized
%
% This is the **main interface** for computing the **minimal bisimulation** of a system
% using a **generalized approach**, supporting both **standard (set-based)** and **matrix-based** algorithms.
%
% INPUT:
% - filename      : String. Name of the file containing the automaton specification.
% - algorithm     : String. Specifies the bisimulation algorithm to use:
%                   - `'standard'` → Generalized standard set-based refinement.
%                   - `'matrix'`   → Generalized matrix-based refinement.
% - verbose_sts   : Integer (0 or 1). If set to 1, prints the internal structure of the STS using `printSTS_gen`.
% - all_process   : Integer controlling the verbosity of the refinement process:
%                   - 0 = silent
%                   - 1 = show partition updates and transitions
%                   - 2 = detailed debugging (e.g., print symbols, preimages, and decisions)
%
% FUNCTIONALITY:
% 1. Loads the automaton into a structured transition system `T` using `STS(filename)`.
% 2. Optionally prints the structure of `T` using `printSTS_gen`.
% 3. Prints a separator using `header()`.
% 4. Based on the selected algorithm:
%    - `'standard'`:
%       - Calls `generalized_bisimulation_standard_algorithm(T, all_process)`
%       - Displays the initial and final partitions using `display_Pi`
%    - `'matrix'`:
%       - Generates transition matrices with `generate_transition_matrices(T)`
%       - Calls `generalized_bisimulation_matrix_algorithm(T, F, all_process)`
%       - Displays binary matrix partitions using `displayPI_matrix`
%       - Converts to cell format using `binaryMatrixToCellPartitions(...)`
%       - Displays partition sets with `display_Pi(...)`
%
% DEPENDENCIES:
% - STS, printSTS_gen, header
% - generalized_bisimulation_standard_algorithm
% - generalized_bisimulation_matrix_algorithm
% - display_Pi, displayPI_matrix, binaryMatrixToCellPartitions
%
% EXAMPLE USAGE:
%   >> main_bisimulation_generalized('automaton.txt', 'standard', 1, 1);
%   >> main_bisimulation_generalized('automaton.txt', 'matrix', 0, 2);
%
% NOTES:
% - This function allows a unified entry point for multiple bisimulation strategies.
% - Particularly useful for comparing results across algorithmic approaches.
% - Generalized methods account for more complex final state structures, such as multi-class final sets.
%
% Main function for using the generalised algorithm 
function main_bisimulation_generalized(filename, algorithm, verbose_sts, all_process)

    % create a STS structure 
    T=STS(filename);
    if verbose_sts==1
        printSTS_gen(T);
    end
    
    % initial header
    header();
    %if the choosen algorithm is standard, proceed according 
    % to the function that implements the standard generalised algorithm
    if strcmp(algorithm,'standard')

         [PI_sim,initial_pi]=generalized_bisimulation_standard_algorithm(T,all_process);
         display_Pi(PI_sim,initial_pi);
   
    elseif strcmp(algorithm,'matrix')
            %generate the transition matrix F
            F=generate_transition_matrices(T);
            [PI_sim,initial_Pi]=generalized_bisimulation_matrix_algorithm(T,F,all_process);
            displayPI_matrix(PI_sim,initial_Pi);
            partitions=binaryMatrixToCellPartitions(PI_sim);
            partitions_in=binaryMatrixToCellPartitions(initial_Pi);
            display_Pi(partitions,partitions_in);

    end

end