%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% FUNCTION: bisimulation_matrix_algorithm
%
% This function computes the minimal bisimulation partition of a given 
% deterministic finite automaton (DFA) using a binary matrix representation 
% for transitions and partitions. The algorithm iteratively refines state 
% equivalence classes based on distinguishability through transitions.
%
% INPUT:
% - A STS T 
% - A transitions matrix F 
% - Parameter to set print of all process 
%
% OUTPUT:
% - Pi_sim: A binary matrix where:
%   - Rows correspond to partitions.
%   - Columns correspond to states.
%   - A value of 1 in (i, j) means that state j belongs to partition i.
%
% FUNCTIONALITY:
% 1. Initializes the partition matrix Π as a binary representation, where:
%    - The first partitions are determined by separating:
%      - {S0 \ SF}: States that are initial but not final.
%      - {SF \ S0}: States that are final but not initial.
%      - {S0 ∩ SF}: States that are both initial and final.
%      - {S \ (S0 ∪ SF)}: All remaining states.
% 2. Iteratively refines the partitions:
%    - It checks if any subset of a partition has distinct behavior under transitions.
%    - If a subset is distinguishable under a transition, the partition is split.
%    - The process continues until no further refinement is possible.
% 3. Returns the final partitions as a binary matrix representation.
%
% DEPENDENCIES:
% - 'read_nfa' to parse the automaton from file.
% - 'STS' to convert the automaton into a structured transition system.
% - 'generate_transition_matrices' to construct transition matrices.
% - 'display_F' to print transition matrices for debugging.
%
% NOTE:
% - The function assumes a correctly formatted input automaton.
% - The resulting partition groups equivalent states, meaning states within 
%   the same partition are indistinguishable in terms of their transitions.
% - The binary matrix representation allows for efficient computation and 
%   easy visualization of the bisimulation process.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function [Pi,initial_pi] = generalized_bisimulation_matrix_algorithm(T,F, all_process)
    % F: cell array with transition matrices F_j for each symbol e_j
    % S0: initial states
    % SF: final states
    % S: set of all states
   
    
    % STEP 1: Initialize Pi as a binary matrix
    Pi = [];
    

    % STEP 2 : States in S0 but not in SF
    if ~isempty(setdiff(T.S0, union_all(T.SF)))
        Pi = [Pi; ismember(T.S, setdiff(T.S0,union_all(T.SF)))];   
        %disp(['Pi:', mat2str(Pi)]);
    end                                                                     % ismember(T.S, X) is used to represent
                                                                            % partition classes in binary form, i.e.
                                                                            % as indicator vectors (0 or 1).   
                                                                            % This is useful for manipulating the partition in an
                                                                            % efficiently, especially in bisimulation algorithms.
      
   
    % Step 3:Iteration on final sets SF_i 
    for i=1:length(T.SF)
       if  ~isempty(intersect(T.S0, T.SF{i}))
            Pi=[Pi; ismember(T.S, intersect(T.S0, T.SF{i}))];
       end
       if ~isempty(setdiff(T.SF{i}, T.S0))
            Pi=[Pi; ismember(T.S, setdiff(T.SF{i}, T.S0))];
       end
    end
 
    % States not in S0 nor in SF
    if ~isempty(setdiff(T.S, union(T.S0, union_all(T.SF))))
        Pi = [Pi; ismember(T.S, setdiff(T.S, union(T.S0, union_all(T.SF))))];
         %disp(['Pi:',mat2str(Pi)]);
    end
    initial_pi=Pi;
    % Initialize the list of partitions to be analyzed
    changed=true;
while changed
    changed = false;

    for pi_target_idx = 1:size(Pi, 1)
        pi_target = Pi(pi_target_idx, :);

        if all_process == 2
            fprintf('\n====================================\n');
            fprintf('Analysis of the pi_target class_%d: %s\n', pi_target_idx, mat2str(find(pi_target)-1));
        end

        for sigma = 1:length(F)
            Pre_sigma = sign(F{sigma} * pi_target');  % column vector
            Pre_sigma = Pre_sigma';                          % row vector :transformed to row by comparison with pi_check

            if all_process == 2
                fprintf('\n  - Symbol σ = ''%s''\n', T.Sigma{sigma});
                if all(Pre_sigma == 0)
                    fprintf('    Predecessors (pre_σ(pi_target)): ∅\n');
                else
                    fprintf('    Predecessors (pre_σ(pi_target)): %s\n', mat2str(find(Pre_sigma)-1));
                end
            end

            for pi_check_idx = 1:size(Pi, 1)
                pi_check = Pi(pi_check_idx, :);
                inter = Pre_sigma & pi_check;

                if all_process == 2
                    fprintf('    > Control over pi_%d: %s\n', pi_check_idx, mat2str(find(pi_check)-1));
                    if any(inter)
                        fprintf('      ↳ Intersection: %s\n', mat2str(find(inter)-1));
                    else
                        fprintf('      ↳ No intersection\n');
                    end
                end

                if any(inter) && ~isequal(inter, pi_check)
                    % Split necessario
                    diff = pi_check & ~inter;

                    Pi(pi_check_idx, :) = inter;
                    Pi(end+1, :) = diff;

                    changed = true;

                    if all_process==1
                        fprintf('\n pi_target class_%d: %s\n', pi_target_idx, mat2str(find(pi_target)-1));
                        fprintf('\n  - Symbol σ = ''%s''\n', T.Sigma{sigma});
                        fprintf('    Predecessors (pre_σ(pi_target)): %s\n', mat2str(find(Pre_sigma)-1));
                        fprintf('\n      Split executed on the pi_%d\n', pi_check_idx);
                        fprintf('    >  pi_%d: %s\n', pi_check_idx, mat2str(find(pi_check)));
                        fprintf('        New pi_%d: %s\n', pi_check_idx, mat2str(find(inter)-1));
                        fprintf('        New pi_%d: %s\n', length(Pi), mat2str(find(diff)-1));
                        fprintf('\n    Updated partitions:\n');
                        for k = 1:size(Pi,1)
                            fprintf('        pi_%d: %s\n', k, mat2str(find(Pi(k, :)) - 1));
                        end
                    end 

                    if all_process == 2
                        fprintf('\n      Split performed on pi_%d\n', pi_check_idx);
                        fprintf('        New pi_%d: %s\n', pi_check_idx, mat2str(find(inter)-1));
                        fprintf('        New pi_%d: %s\n', size(Pi,1), mat2str(find(diff)-1));
                        fprintf('    Updated partitions:\n');
                        for k = 1:size(Pi, 1)
                           fprintf('        pi_%d: %s\n', k, mat2str(find(Pi(k, :)) - 1));
                        end
                    end

                    break;  % Restart: new Pi updated
                end
            end

            if changed
                break;
            end
        end

        if changed
            break;
        end
    end
end

end
 



%% FUNCTION: union_all
%
% This function computes the union of all elements in a given cell array.
% It is used to handle multiple subsets of final states in bisimulation calculations.
%
% INPUT:
% - cell_array: A cell array where each element is a numeric vector of states.
%
% OUTPUT:
% - result: A numeric vector containing the union of all elements in cell_array.
%
% FUNCTIONALITY:
% 1. If the input is not a cell array, it is converted into one.
% 2. Iterates over all elements in the cell array and computes their union.
% 3. Returns a numeric vector representing the union of all elements.
%
function result = union_all(cell_array)
    result = [];
    if ~iscell(cell_array)
        cell_array = {cell_array}; % Convert to cell array if necessary
    end
    for i = 1:length(cell_array)
        result = union(result, cell_array{i});
    end
end