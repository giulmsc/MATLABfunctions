
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% FUNCTION: get_predecessors
%
% This function computes the set of **predecessor states** for a given subset of states `pi`
% with respect to a specific transition symbol `sigma`, based on the transition relation of 
% the automaton.
%
% INPUT:
% - transitions: An N×3 matrix representing the transition relation of the automaton.
%     Each row is a transition of the form:
%     [source_state, symbol_index, target_state]
% - pi: A vector containing a subset of target states.
% - sigma: A numeric index representing the transition symbol of interest.
%
% OUTPUT:
% - Pre_sigma: A vector of states (without duplicates) from which a state in `pi` 
%              can be reached using a transition labeled with symbol `sigma`.
%
% FUNCTIONALITY:
% 1. Initializes an empty vector `Pre_sigma`.
% 2. Iterates over each row in the `transitions` matrix.
%    - If the symbol matches `sigma` **and** the arrival state is in `pi`,
%      the source state is considered a predecessor and added to `Pre_sigma`.
% 3. At the end, duplicates are removed using `unique()`.
%
% USAGE EXAMPLE:
%   If `pi = [3 5]` and `sigma = 2`, the function returns all states from which
%   state 3 or 5 can be reached by a transition labeled with symbol 2.
%
% APPLICATION:
% - Used in bisimulation algorithms (standard or matrix-based) to determine how 
%   a block of states can be distinguished based on incoming transitions.
%
% NOTE:
% - The transition symbols must already be mapped to numeric indices (e.g., via `sigma_map`).
% - The returned set is sorted and contains no duplicates.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function Pre_sigma = get_predecessors(transitions, pi , sigma)
    % transitions is an Nx3 matrix where:
    % - column 1: starting state
    % - column 2: symbol (numeric index)
    % - column 3: arrival state

    Pre_sigma = []; %Initialisation of pre_σ as an empty vector
    % Find all transitions for the sigma_num symbol
    for i = 1:size(transitions, 1) %analysing transitions line by line
        if transitions(i, 2) == sigma && ismember(transitions(i, 3), pi)
            %% transitions(i, 2) == sigma: 
            % checks whether the transition symbol 
            % (in the second column of transitions) is equal to the sigma symbol.
            %% ismember(transitions(i, 3), pi_prime): 
            % checks whether the target state of the transition 
            % (third column of transitions) is present in pi_prime
            Pre_sigma = [Pre_sigma, transitions(i, 1)]; 
            % the starting state of the transition is added to Pre_sigma
        end
    end
    
    % Remove duplicates from predecessors
    Pre_sigma = unique(Pre_sigma);
end
