%% FUNCTION: main_bisimulation_matrix
%
% This is the **main driver function** for computing a **minimal bisimulation**
% of a transition system using a **matrix-based algorithm**.
%
% INPUT:
% - filename   : String, name of the file containing the automaton description.
% - print_F    : Flag (0 or 1). If set to 1, prints the symbolic transition matrices `F`.
% - all_process: Verbosity level for displaying intermediate steps:
%                - 0 = silent,
%                - 1 = shows detailed partition refinement process,
%                - 2 = shows detailed split diagnostics.
%
% FUNCTIONALITY:
% 1. Loads the automaton using `STS(filename)` and creates the structure `T`.
% 2. If `all_process == 1`, displays the automaton with `printSTS_st(T)`.
% 3. Generates the **transition matrices** `F`, one for each event in the alphabet, 
%    using `generate_transition_matrices(T)`. Each `F{i}` is an `n x n` binary matrix.
% 4. If `print_F == 1`, prints all the transition matrices with `display_F(F)`.
% 5. Prints a separator using `header()`.
% 6. Computes the **minimal bisimulation partition** using:
%       `[PI_sim, initial_pi] = bisimulation_matrix_algorithm(T, F, all_process)`
%    - The partitions are represented as binary matrices (each row = indicator vector).
% 7. Displays the initial and final partition using `displayPI_matrix(...)`.
%
% OPTIONAL (commented):
% - Convert binary matrix to cell format for further manipulation using `binaryMatrixToCellPartitions`.
% - Construct and display the quotient automaton via `quotientSTS(T, PI_sim)` and `printSTS`.
%
% EXAMPLE:
%   >> main_bisimulation_matrix('example.txt', 1, 1);
%
% DEPENDENCIES:
% - STS, generate_transition_matrices, display_F, header
% - bisimulation_matrix_algorithm, displayPI_matrix
%
% NOTE:
% - The matrix-based bisimulation algorithm is efficient and particularly suitable
%   for large systems with sparse transition relations.
% - Useful in contexts where a symbolic or linear-algebraic approach is preferred.
%
% principal function to compute a minimal bisimulation with matrix approach
function main_bisimulation_matrix(filename,print_F, all_process)
    
    % create a STS structure
   
    T=STS(filename);
    if all_process==1
        printSTS_st(T);
    end
    
    
    % create a transition matrices
    F=generate_transition_matrices(T);
    % if print_F is equal to 1 view the transition matrix F
    if print_F==1
        display_F(F);
    end
    header();
    % compute minimal bisimulation 
    [PI_sim,initial_pi]=bisimulation_matrix_algorithm(T,F, all_process);
    
    %view the final partition
    displayPI_matrix(PI_sim,initial_pi);
    %partitions_in=binaryMatrixToCellPartitions(initial_pi);
    %partitions=binaryMatrixToCellPartitions(PI_sim);
    %display_Pi(partitions,partitions_in);
  
    %Tq=quotientSTS(T,PI_sim);
    %printSTS(Tq);

end

