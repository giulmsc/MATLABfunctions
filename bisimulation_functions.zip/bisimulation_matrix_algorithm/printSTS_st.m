
function printSTS_st(T)
fprintf('\n');
    disp('Structure of T:');
    fprintf('\n');
    disp(['  |S|:', mat2str(T.Snumber)]);
    fprintf('\n');
    disp(['   S:',mat2str(T.S)]);
    fprintf('\n');
    %disp(mat2str(T.S));
    result = ['[', strjoin(T.Sigma, ' '), ']'];
    disp(['   Sigma:',result]);
    fprintf('\n');
   % Creazione di una stringa compatta
    Sigma_map_compact = '';
    keys = T.Sigma_map.keys;
    for i = 1:length(keys)
        key = keys{i};
        value = T.Sigma_map(key); % Accesso al valore tramite chiave
        Sigma_map_compact = [Sigma_map_compact, sprintf('%d ',value)];
    end
    % Rimuovi la virgola finale
    Sigma_map_compact = ['[', Sigma_map_compact(1:end-1), ']'];

    % Stampa il risultato
    disp(['   Sigma_map: ', Sigma_map_compact]);
        fprintf('\n');
    disp('    Transition:');
    disp(T.transitions)
    disp(['   S0:',mat2str(T.S0)]);
    fprintf('\n');
    disp(['   SF:',mat2str(T.SF)]);
     fprintf('\n');
end