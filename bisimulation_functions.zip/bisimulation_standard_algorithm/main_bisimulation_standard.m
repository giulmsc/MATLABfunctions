
% principal function to compute a minimal bisimulation 
%% FUNCTION: main_bisimulation_standard
%
% This is the **main driver function** to compute and display the **minimal bisimulation**
% of a given automaton using the **standard iterative refinement algorithm**.
%
% INPUT:
% - filename     : String, name of the file containing the automaton description.
% - all_process  : Integer flag to control the verbosity level:
%                  - `0` = no intermediate details,
%                  - `1` = show intermediate partition refinement steps.
%
% FUNCTIONALITY:
% 1. Loads the automaton from file using `STS(filename)`, converting it into a structured STS.
% 2. Optionally displays the structure `T` using `printSTS_st` if `all_process == 1`.
% 3. Prints a header using `header()` (presumably for formatting/logging).
% 4. Computes the minimal bisimulation partition using:
%       `bisimulation_standard_algorithm(T, all_process)`
% 5. Displays the final partition using `displayPI(partitions)`.
%
% DEPENDENCIES:
% - `STS`: Parses the input file into a transition system structure.
% - `printSTS_st`: Optional, for displaying the structure T.
% - `header`: Prints visual/logging separator.
% - `bisimulation_standard_algorithm`: Core algorithm for bisimulation computation.
% - `displayPI`: Prints the resulting partition.
%
% EXAMPLE USAGE:
%   >> main_bisimulation_standard('example.txt', 1);
%
% NOTES:
% - This function is intended for **interactive use or script-based analysis** of automata.
% - You can adjust `all_process` to debug or analyze refinement behavior.
% - The function focuses on **standard bisimulation**, but can be adapted to call other variants (e.g., stochastic, matrix-based).
%

function main_bisimulation_standard(filename, all_process)
    
    % create a STS structure 
    T=STS(filename);
    if all_process==1
        printSTS_st(T);
    end
    
    % initial header
    header();
    
    % compute bisimulation with standard algorithm
    partitions=bisimulation_standard_algorithm(T, all_process);

    %view results 
    displayPI(partitions);
    
end
