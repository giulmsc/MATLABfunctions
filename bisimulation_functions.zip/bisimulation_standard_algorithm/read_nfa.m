%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% function to read the charateristics of DFA from a file 

% FUNCTION: read_nfa
%
% This function reads the characteristics of a Deterministic Finite Automaton (DFA) 
% from a file and stores them in a structured format. The function also provides 
% options to display the transition matrix in numeric or symbolic form.
%
% INPUT:
% - file_name: A string containing the path to the file with the DFA definition.
% - nt: A flag (1 or 0) to decide whether to display the numeric transition matrix 
%       (where symbols are represented as numbers).
% - st: A flag (1 or 0) to decide whether to display the transition matrix with 
%       symbols as represented in the file.
%
% OUTPUT:
% - G: A structure containing the DFA properties:
%     - G.states: Number of states.
%     - G.alphabet: Cell array of symbols in the alphabet.
%     - G.obs_events: List of observable events.
%     - G.obs_map: Mapping of observable events to numeric indices.
%     - G.unobs_events: List of unobservable events.
%     - G.unobs_map: Mapping of unobservable events to numeric indices.
%     - G.fault_events: List of fault events.
%     - G.transitions: Cell array of transitions in the format {state1, symbol, state2}.
%     - G.D: Numeric transition matrix where symbols are mapped to numbers.
%     - G.initialStates: Vector containing initial states.
%     - G.finalStates: A cell array of sets of final states, where:
%       - If there are multiple final state groups (separated by ';' in the file), 
%         each group is stored as a separate vector.
%       - If there is only one group, it is stored as a single numeric vector.
%       - If there are no final states, the entry is {'No final states'}.
%
% FUNCTIONALITY:
% 1. Opens and reads the DFA definition file line by line.
% 2. Extracts the number of states, alphabet, observable and unobservable events, 
%    fault events, and transition definitions.
% 3. Stores transitions in a cell array and validates state indices.
% 4. Builds a numeric transition matrix (G.D) where symbols are replaced with numeric indices.
% 5. Maps observable and unobservable events using a dictionary structure.
% 6. Handles the final states:
%    - If multiple groups of final states exist (separated by ';'), they are stored 
%      as a cell array, where each group is a numeric vector.
%    - If only one group exists, it is stored as a single numeric vector.
%    - If no final states exist, the entry is stored as {'No final states'}.
% 7. Displays the DFA structure if requested.
%
% DEPENDENCIES:
% - 'create_transition_matrix' to construct the numeric transition matrix.
%
% NOTE:
% - This function assumes the input file is correctly formatted.
% - The output structure G provides a complete representation of the DFA, making it 
%   suitable for further processing in verification and bisimulation algorithms.
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%% 


function G = read_nfa(file_name, nt, st)
    % Open the file
    fileID = fopen(file_name, 'r');
    if fileID == -1
        error('cannot open the file: %s', file_name);
    end

    % Initialize structure
    G = struct();
    G.states = [];
    G.alphabet = '';
    G.obs_events = [];
    G.obs_map=[];
    G.unobs_events = [];
    G.unobs_map=[];
    G.fault_events = [];
    G.transitions = {};
    G.D=[];
    G.initialStates = [];
    G.finalStates = {};

    % Read the file line by line
    while ~feof(fileID)
        line = strtrim(fgetl(fileID)); % Read one line and remove spaces

        % Skip blank lines or comments
        if isempty(line) || startsWith(line, '%')
            continue;
        end

        % States number
        if isempty(G.states)
            G.states = str2double(line);
            continue;
        end

        % Alphabet
        if isempty(G.alphabet)
            G.alphabet = strsplit(line, ' ');
            continue;
        end

        % Observable events
        if isempty(G.obs_events)
            G.obs_events = strsplit(line, ' ');
            continue;
        end

        % Unobservable events
        if isempty(G.unobs_events)
            if strcmp(line, '-')
                G.unobs_events = {'No unobservable events'}; % No unobservable events
                check_unobs_events=0;
            else
                G.unobs_events = strsplit(line, ' ');
                check_unobs_events=1;
            end
            continue;
        end

        %Fault events
        if isempty(G.fault_events)
            if strcmp(line, '-')
                G.fault_events = {'No fault events'}; % No unobservable events
            else
                G.fault_events = strsplit(line, ' ');
            end
            continue;
        end

        % Matrice di transizione
        if isempty(G.transitions)
            transitions = {};
            %read the first line of the matrix
            % Split the line into start state, symbol, and end state
                parts = strsplit(line, ' ');

                % Check if the number of parts is correct
               if length(parts) >= 3
                    
                stato1 = str2double(parts{1});
                if stato1 > G.states-1 || stato1 < 0
                    error(['Error in start state of the trasition matrix, line: ', line]);
                end

                simbolo = parts{2};
                stato2 = str2double(parts{3});
                if stato2 > G.states-1 || stato2 < 0 
                    error(['Error in start state of the trasition matrix, line: ', line]);
                end
                % Append the new transition to the transition matrix
                  transitions = [transitions; {stato1, simbolo, stato2}];
               else 
                    error('Invalid transition line: "%s". Expected format: "initial state symbol final state" ', line);
               end
            %read next lines
            while ~feof(fileID)
                line = strtrim(fgetl(fileID));
                
                if startsWith(line, '% Initial state') || isempty(line) % Signal to stop reading transitions
                    break;
                end

                % Split the line into start state, symbol, and end state
                parts = strsplit(line, ' ');

                % Check if the number of parts is correct
               if length(parts) >= 3
                    
                stato1 = str2double(parts{1});
                if stato1 > G.states-1 || stato1 < 0
                    error(['Error in start state of the trasition matrix, line: ', line]);
                end

                simbolo = parts{2};
                stato2 = str2double(parts{3});
                if stato2 > G.states-1 || stato2 < 0 
                    error(['Error in start state of the trasition matrix, line: ', line]);
                end
                % Append the new transition to the transition matrix
                  transitions = [transitions; {stato1, simbolo, stato2}];
                  
               else 
                    error('Invalid transition line: "%s". Expected format: "initial state symbol final state" ', line);
               end
              
            end
            G.transitions = transitions;
            continue;
        end
      
        
        % Initial states
        if isempty(G.initialStates)
            G.initialStates = str2double(strsplit(line, ' '));
            continue;
        end

        % Final states
    
        % Final states
        if isempty(G.finalStates)
            if strcmp(line, '-')
                G.finalStates = {'No final states'};
            else
                finalStatesLines = {line};  % La prima riga viene subito salvata
        
                % Continua a leggere le righe finché non si incontra una riga vuota o un nuovo blocco
                while ~feof(fileID)
                    line = strtrim(fgetl(fileID));
                    if isempty(line) || startsWith(line, '%')  % Se la riga è vuota o un nuovo blocco, interrompi
                        break;
                    end
                    finalStatesLines{end+1} = line; % Aggiunge la riga alla lista
                end
                
                % Se c'è una sola riga, l'insieme è unico
                if length(finalStatesLines) == 1
                    G.finalStates = str2double(strsplit(finalStatesLines{1}, ' '));
                else
                    % Se ci sono più righe, ciascuna è un insieme separato
                    G.finalStates = cellfun(@(x) str2double(strsplit(x, ' ')), finalStatesLines, ...
                        'UniformOutput', false);
                end
            end
        end
    end
    % Close the file

    fclose(fileID);

    %alphabet map 
    num_symbols = length(G.alphabet);
    alphabet_map = containers.Map(G.alphabet, num2cell(1:num_symbols));
    
    G.D=create_transition_matrix(transitions,alphabet_map);
    % Map observable events 
       G.obs_map = zeros(1, numel(G.obs_events));
            for i = 1:numel(G.obs_events)
                event = G.obs_events{i}; %Get the observable event
                if isKey(alphabet_map, event) % Check if the event is present in the map
                    G.obs_map(i) = alphabet_map(event); % Use the event directly as a key
                else
                     error(['Observable event not found in the alphabet: ', G.obs_events{i}]);
                end
            end

    % Map unobservable events (if present)
    if check_unobs_events ~= 0
        %disp('No Unobservable event present')
    %else
        G.unobs_map = zeros(1, numel(G.unobs_events));
             for i = 1:numel(G.unobs_events)
                 event = G.unobs_events{i}; % Ottieni l'evento osservabile
                if isKey(alphabet_map, event) % Controlla se l'evento è presente nella mappa
                    G.unobs_map(i) = alphabet_map(event); % Usa direttamente l'evento come chiave
                else
                     error(['Unobservable event not found in the alphabet: ', G.unobs_events{i}]);   
                end
            end
    end
    fprintf('============================');
    fprintf('\n');
    fprintf('Structure of G:');
    fprintf('\n');
    disp(G);
    
    if nt==1
        fprintf('--------------------------------');
        fprintf('\n')
        fprintf('transitions:')
        fprintf('\n')
        fprintf('%-8s %-8s %-8s\n', 'State1', 'Event', 'State2'); 
        for i = 1:size(G.D, 1)
             fprintf('%-8d %-8d %-8d\n', G.D(i,1), G.D(i,2), ...
                    G.D(i,3));
        end
        fprintf('\n')
        fprintf('--------------------------------');
    end

    if st==1
        fprintf('\n')
        fprintf('transitions:')
        fprintf('\n')
        fprintf('%-8s %-8s %-8s\n', 'State1', 'Event', 'State2'); 
        for i = 1:size(G.transitions, 1)
             fprintf('%-8d %-8s %-8d\n', G.transitions{i,1}, G.transitions{i,2}, ...
                    G.transitions{i,3});
        end
        fprintf('\n')
        fprintf('--------------------------------');
    end
    fprintf('\n')
    
end