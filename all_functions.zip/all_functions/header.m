
function header()
fprintf('============================');
    fprintf('\n');
    fprintf('Minimal bisimulation process');
    fprintf('\n');
    fprintf('============================');
    fprintf('\n');
end