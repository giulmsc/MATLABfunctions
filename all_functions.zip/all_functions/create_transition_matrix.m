%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% FUNCTION: create_transition_matrix
%
% This function constructs a transition matrix from a given set of transitions 
% and an alphabet-to-numeric mapping.
%
% INPUT:
% - transitions: A cell array where each row represents a transition in the format:
%                {state1, symbol, state2}, where:
%                  * state1  - The starting state.
%                  * symbol  - The transition symbol.
%                  * state2  - The destination state.
% - alphabet_map: A containers.Map object mapping symbols from the alphabet 
%                 to numerical indices.
%
% OUTPUT:
% - transition_matrix: An Nx3 matrix where each row corresponds to a transition:
%                      [state1, symbol_index, state2], where:
%                        * state1       - The starting state.
%                        * symbol_index - The numeric representation of the transition symbol.
%                        * state2       - The destination state.
%
% FUNCTIONALITY:
% 1. Initializes an empty transition matrix.
% 2. Iterates through the given transitions to extract states and symbols.
% 3. Uses the provided alphabet_map to convert symbols into numeric indices.
% 4. Constructs the transition matrix by mapping each transition into numerical format.
%
% NOTE:
% - The function assumes that 'transitions' is formatted correctly.
% - The alphabet_map must contain all symbols used in transitions.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


function transition_matrix = create_transition_matrix(transitions, alphabet_map)
   

    % Preallocates the matrix of transitions
    num_transitions = size(transitions, 1);
    transition_matrix = [];

    %Fill in the transitions matrix
    for i = 1:num_transitions
        stato1 = transitions{i, 1};
        simbolo = transitions{i, 2};
        stato2 = transitions{i, 3};
        
        if iscell(simbolo)
            simbolo = simbolo{1}; % Extract the actual value from the cell
        end
        % Get the numeric index of the symbol
        simbolo_idx = alphabet_map(simbolo);

        % Add transition to matrix
        transition_matrix(i,:)=[stato1, simbolo_idx, stato2];
    end
end