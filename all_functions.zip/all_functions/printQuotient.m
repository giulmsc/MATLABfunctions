function printQuotient(T)
% printSTS - stampa ordinata di un sistema di transizione T (quoziente o normale)

fprintf('=== Quotient System STS ===\n');
fprintf('- Number of states: %d\n', length(T.S));
fprintf('- States: ');
fprintf('q%d ', T.S);
fprintf('\n');

fprintf('- Alphabet: ');
fprintf('%s ', T.Sigma{:});
fprintf('\n');

%fprintf('- Initial states: ');
%fprintf('q%d ', T.S0);
%fprintf('\n');

%fprintf('- Final states: ');
%if iscell(T.SF)
%    final_states = unique([T.SF{:}]);
%else
%    final_states = unique(T.SF);
%end
%fprintf('q%d ', final_states);
%fprintf('\n');

fprintf('- Transitions:\n');
for i = 1:size(T.transitions, 1)
    from = T.transitions(i, 1);
    sigma_idx = T.transitions(i, 2);
    to = T.transitions(i, 3);
    fprintf('  q%d -- %s --> q%d\n', from, T.Sigma{sigma_idx}, to);
end

fprintf('====================\n\n');
end