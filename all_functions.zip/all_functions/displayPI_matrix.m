% function to print the obtained partitions 
function displayPI_matrix(Pi,initial_pi)

          disp('Initial partitions:');
            for i = 1:size(initial_pi,1)
                fprintf('   pi%d: ', i);
                fprintf('%d ', initial_pi(i,:));
                fprintf('\n');
            end
          fprintf('\n');
          disp('Final partitions:');
            for i = 1:size(Pi,1)
                fprintf('   pi%d: ', i);
                fprintf('%d ', Pi(i,:));
                fprintf('\n');
            end
end 