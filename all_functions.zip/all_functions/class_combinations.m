
%% FUNCTION: class_combinations
%
% This function generates **all possible binary classifications** (as accepted or not accepted)
% for the unclassified states of a given automaton. It is particularly useful for 
% **exploring different acceptance scenarios** in DFA construction and testing 
% properties like minimality, equivalence, or diagnosability.
%
% INPUT:
% - automaton: A structure as returned by `build_automaton`, containing:
%     - automaton.states            : Cell array of state names (e.g., {'x0', 'x1', ...}).
%     - automaton.start             : Initial state name (e.g., 'x0').
%     - automaton.accepted_class    : States already marked as accepted.
%     - automaton.notaccepted_class : States already marked as not accepted.
%
% OUTPUT:
% - class_combinations: Array of structs, where each struct contains:
%     - `.accepted`: Cell array of states marked as accepted in that combination.
%     - `.notaccepted`: Cell array of states marked as not accepted.
%   The length of this array is 2^k, where k is the number of states that are
%   **neither initial nor already classified**.
%
% FUNCTIONALITY:
% 1. Computes the set of states that are not the start state and not yet classified
%    as either accepted or not accepted.
% 2. For each of the 2^n possible binary combinations (where n = # unclassified states):
%     - Assigns each state to either the accepted or not accepted class.
%     - Combines them with the already classified states.
%     - Sorts both resulting state lists numerically (e.g., x1 < x10).
% 3. Returns the full list of combinations as an array of structs.
%
% UTILITY FUNCTION:
% - `sort_state_names(state_list)`: Helper that extracts numeric values from
%    state names and sorts them accordingly.
%
% USE CASES:
% - Testing all valid acceptance configurations in automata synthesis.
% - Evaluating the impact of acceptance on language recognition or bisimulation.
% - Exhaustive search for valid minimal DFA variants.
%
% EXAMPLE:
%   >> A = {'x1'};
%   >> N = {'x3'};
%   >> automaton = struct('states', {'x0','x1','x2','x3','x4'}, ...
%                         'start', 'x0', ...
%                         'accepted_class', A, ...
%                         'notaccepted_class', N);
%   >> combos = class_combinations(automaton);
%   >> length(combos)
%   ans = 4    % for 2 unclassified states (x2, x4)
%
% NOTE:
% - The function **does not classify the initial state** (`x0`) unless explicitly removed
%   from the exclusion logic (see commented line in code).
%

function class_combinations = class_combinations(automaton)

    % States to be classified (neither start nor already assigned)
    already_classified = union(automaton.accepted_class, automaton.notaccepted_class);
    states_to_classify = setdiff(setdiff(automaton.states, automaton.start), already_classified);
    
    % Also classifies the initial state as A or N
    %states_to_classify = setdiff(automaton.states, already_classified);
    
    n = length(states_to_classify);
    total_combinations = 2^n;
    class_combinations(total_combinations) = struct('accepted', [], 'notaccepted', []);
    
    for i = 0:(total_combinations - 1)
        bin = dec2bin(i, n) - '0';  % binary vector 0/1

        A = automaton.accepted_class;
        N = automaton.notaccepted_class;

        for j = 1:n
            if bin(j) == 1
                A{end+1} = states_to_classify{j};
            else
                N{end+1} = states_to_classify{j};
            end
        end

        % Sort states
        A = sort_state_names(A);
        N = sort_state_names(N);

        class_combinations(i+1).accepted = A;
        class_combinations(i+1).notaccepted = N;
    end
end

function sorted = sort_state_names(state_list)
    if isempty(state_list)
        sorted = {};
        return;
    end
    state_list = unique(state_list);
    nums = cellfun(@(s) sscanf(s, '%*[a-zA-Z]%d'), state_list);
    [~, idx] = sort(nums);
    sorted = state_list(idx);
end