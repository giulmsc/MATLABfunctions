

% function to display automaton with information 

function display_automaton(automaton)
    fprintf('\n');
    disp('=== Automaton ===')
    disp(['- Number of states: ', num2str(numel(automaton.states))])
    disp(['- States:', strjoin(automaton.states,', ')]);
    disp(['- Initial states: ', automaton.start]);
    disp(['- Final states: ', strjoin(automaton.final,', ')]);
    disp('- Transitions:');
    keysList = keys(automaton.transitions);
    for i = 1:length(keysList)
        k = keysList{i};
        v = automaton.transitions(k);
        fprintf(' %s --> %s\n', k, v);
    end
    disp(['Accepted states (A): ', strjoin(automaton.accepted_class)]);
    disp(['Not accepted states (N): ', strjoin(automaton.notaccepted_class)]);
end