%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% FUNCTION: generate_transition_matrices
%
% This function constructs a set of transition matrices from the given 
% automaton structure. Each transition matrix corresponds to a specific 
% symbol in the alphabet and represents state transitions in a binary format.
%
% INPUT:
% - T: A structured representation of the STS, containing:
%     - T.S: Number of states.
%     - T.Simga: Set of symbols (alphabet).
%     - T.transitions: Transition matrix in the form [state_in, symbol, state_out].
%
% OUTPUT:
% - F: A cell array where each entry F{j} is an |S| × |S| binary matrix 
%      representing transitions under the j-th symbol of the alphabet. 
%      - Rows represent destination states.
%      - Columns represent source states.
%      - A value of 1 at (i, j) means there is a transition from state j to 
%        state i under a specific symbol.
%
% FUNCTIONALITY:
% 1. Initializes an empty cell array of size equal to the number of symbols 
%    in the alphabet.
% 2. Creates an |S| × |S| binary matrix for each symbol, initialized to zeros.
% 3. Iterates over the transition matrix G.D:
%    - Extracts the source state, symbol, and destination state.
%    - Updates the corresponding transition matrix with a 1 at (destination, source).
% 4. Returns the set of transition matrices.
%
% DEPENDENCIES:
% - Requires the automaton structure G to be properly formatted.
% - Used in bisimulation algorithms for efficiently analyzing state 
%   transitions under different input symbols.
%
% NOTE:
% - MATLAB indices start from 1, so state indices are adjusted accordingly.
% - The matrices are constructed in transposed form (destination-state-first) 
%   to facilitate predecessor computation.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function F = generate_transition_matrices(T)
    num_states = length(T.S);  % Number of states
    num_symbols = length(T.Sigma); % Number of symbols in the alphabet
    
    % Initialise a cell array to contain the transition arrays F_j
    F = cell(1, num_symbols);
    
    % Creates binary arrays initialised at zero
    for j = 1:num_symbols
        F{j} = zeros(num_states, num_states); % Matrix n x n for each symbol
    end
    
    % Scan the G.D matrix and fill in the transition matrices
    for i = 1:size(T.transitions, 1)
        initial_state = T.transitions(i, 1) + 1; % MATLAB uses indices of 1, in the STS states start with 0 
                                                  % then add 1 is necessary to align with matlab convection
        symbol = T.transitions(i, 2); % Numeric symbol
        final_state = T.transitions(i, 3) + 1; %MATLAB uses indices from 1, in the STS states start with 0 
                                                  % then add 1 is necessary to align with matlab convection
        
        % Updates the transition matrix for the current symbol
        F{symbol}(initial_state, final_state) = 1;
    end
end