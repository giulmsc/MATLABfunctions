function Tq = quotientSTS_withclass(T, Pi, classes)
% Tq = quotientSTS(T, Pi, classes)
% Costruisce l'automa quoziente Tq a partire da T, dalla partizione Pi
% e dalla classificazione accepted/notaccepted degli stati originali.

n_blocks = length(Pi);
alphabet = T.Sigma_map;  % cell array di eventi
m = length(alphabet);
keys_alphabet = keys(alphabet);
values_alphabet = values(alphabet);

% Mappa dagli stati originali al blocco
state_to_block = zeros(1, length(T.S));
for b = 1:n_blocks
    state_to_block(Pi{b} + 1) = b;
end

% Inizializza transizioni del quoziente
Transitions = [];

% Per ogni coppia di blocchi (π, π′), verifica se π ⊆ Pre_σ(π′)
for i = 1:n_blocks
    for j = 1:n_blocks
        for k = 1:m  % per ogni evento σ = Sigma{k}
            sigma = values_alphabet{k};
            pre_sigma = get_predecessors(T.transitions, Pi{j}, sigma);
            if all(ismember(Pi{i}, pre_sigma))
                % Aggiungi transizione nel quoziente: π_i --σ--> π_j
                Transitions = [Transitions; i, k, j];
            end
        end
    end
end

% Stati iniziali del quoziente = blocchi che contengono stati iniziali
S0q = [];
for b = 1:n_blocks
    if any(ismember(Pi{b}, T.S0))
        S0q(end+1) = b;
    end
end

% Blocchi accettanti e non accettanti
% Se accepted/notaccepted sono stringhe numeriche, convertili
% Converti 'xN' in interi
accepted_states = cellfun(@(s) sscanf(s, 'x%d'), classes.accepted);
notaccepted_states = cellfun(@(s) sscanf(s, 'x%d'), classes.notaccepted);
Aq = [];  % Blocchi accettanti
Nq = [];  % Blocchi non accettanti

for b = 1:n_blocks
    block_states = Pi{b};
    if any(ismember(block_states, accepted_states))
        Aq(end+1) = b;
    elseif any(ismember(block_states, notaccepted_states))
        Nq(end+1) = b;
    end
end

% Costruisci il nuovo sistema quoziente
Tq.Snumber=n_blocks;
Tq.S = 1:n_blocks;
Tq.Sigma = keys_alphabet;
Tq.S0 = unique(S0q);
Tq.transitions = Transitions;
Tq.Sigma_map = T.Sigma_map;

% Stati accettanti e non accettanti nel quoziente
Tq.class_A = unique(Aq);
Tq.class_N = unique(Nq);

end