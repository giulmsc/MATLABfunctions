%% FUNCTION: convert_to_write_format
%
% This function converts a DFA structure (`DFA_in`) into a format compatible with the `write_nfa`
% function or similar file-output routines. It prepares the automaton in a standardized
% structure including alphabet, states, events, transitions, and labeling.
%
% INPUT:
% - DFA_in: A structure representing a Deterministic Finite Automaton, with fields:
%     - DFA_in.States        : Row vector of numeric state identifiers.
%     - DFA_in.Alphabet      : Cell array of event labels (symbols).
%     - DFA_in.InitialState  : Numeric value representing the initial state.
%     - DFA_in.FinalStates   : Row vector of numeric final states.
%     - DFA_in.Transitions   : A `containers.Map` where:
%                               - Keys are strings of the form `'state,event'`
%                               - Values are numeric destination states.
%
% OUTPUT:
% - DFA_out: A structure formatted for compatibility with tools like `write_nfa`, with fields:
%     - DFA_out.states           : Column cell array of state names (as strings).
%     - DFA_out.alphabet         : Cell array of event symbols.
%     - DFA_out.obs_events       : Same as the alphabet (all events are observable).
%     - DFA_out.unobs_events     : {'No unobservable events'} (placeholder).
%     - DFA_out.fault_events     : {'No fault events'} (placeholder).
%     - DFA_out.state_map        : Map from state label (string) → numeric state ID.
%     - DFA_out.initialStates    : Initial state (numeric).
%     - DFA_out.finalStates      : Final states (numeric vector).
%     - DFA_out.transitions      : Cell array of string-based transitions, each row:
%                                  {from_state_str, symbol_str, to_state_str}
%
% FUNCTIONALITY:
% 1. Converts the numeric state list into string labels for compatibility.
% 2. Assumes all events in the alphabet are observable.
% 3. Copies the DFA's initial and final states directly.
% 4. Transforms the `Transitions` map into a 3-column cell array representing transitions.
%     - Keys in the form `'s,event'` are split.
%     - Source and target states are stored as strings.
%
% USE CASE:
% - Preparing a DFA structure for export to file via `write_nfa` or other formats 
%   expecting labeled states and symbolic transitions.
%
% EXAMPLE KEY FORMAT:
%   A transition from state 2 to 3 on symbol `'a'` would appear in `DFA_in.Transitions` as:
%       key: `'2,a'`
%       value: 3
%
% NOTE:
% - States in the output are stored as **strings**, as required by `write_nfa`.
% - The function does **not** validate the consistency of the DFA input.
% - Transition events are assumed to be correct and consistent with the alphabet.
%

function DFA_out = convert_to_write_format(DFA_in)
    % convert_to_write_format converte un DFA generato in formato compatibile con write_nfa

    % Copy alphabet and states
    DFA_out.alphabet = DFA_in.Alphabet;
    DFA_out.states = DFA_in.States';

    % Observable, non-observable, failure events
    DFA_out.obs_events = DFA_in.Alphabet;  % All observable
    DFA_out.unobs_events = 'No unobservable events';
    DFA_out.fault_events = 'No fault events';

    % Construction state_map: label → numeric index
    DFA_out.state_map = containers.Map();
    for i = 1:length(DFA_out.states)
        label = num2str(DFA_out.states(i));
        DFA_out.state_map(label) = DFA_out.states(i); 
    end

    %Initial state
    DFA_out.initialStates = DFA_in.InitialState;

    % Final states
    DFA_out.finalStates = DFA_in.FinalStates;

    %Transitions: from containers.Map to cell array
    keysT = DFA_in.Transitions.keys;
    DFA_out.transitions = cell(length(keysT), 3);
    for i = 1:length(keysT)
        key = keysT{i};
        parts = split(key, ',');
        s_from = str2double(parts{1});
        event = parts{2};
        s_to = DFA_in.Transitions(key);
        DFA_out.transitions{i,1} = num2str(s_from);
        DFA_out.transitions{i,2} = event;
        DFA_out.transitions{i,3} = num2str(s_to);
    end
end