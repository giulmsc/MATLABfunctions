
%% function that reads the file and generates a state transition system (STS) 
%% T=(S,Σ,transitionRelation, S_0,S_F)


function T = STS_fromG(G, print_T)
    % read the automaton
    
    
    % Estrai gli elementi necessari
    T.Sigma_map=containers.Map();
    T.S = 0:G.states-1; % set of states
    T.Snumber=G.states;
    T.Sigma = G.alphabet; % set of generators = alphabet
    num_symbol=length(T.Sigma);
    T.Sigma_map=containers.Map(T.Sigma, num2cell(1:num_symbol));
    T.transitions = create_transition_matrix(G.transitions, T.Sigma_map); % transition relation = transition
    T.S0 = G.initialStates; % set of initial states
    T.SF = G.finalStates; % set of final states
    
    if print_T==1
        printSTS_gen(T);
    end
    
    
end