function printSTSq(T)
fprintf('\n');
fprintf('===================================== \n');
    disp('Quotient automata obtained with best PI:');
fprintf('\n');
disp(['  |S|:', mat2str(T.Snumber)]);
fprintf('\n');
disp(['   S:', mat2str(T.S)]);
fprintf('\n');

result = ['[', strjoin(T.Sigma, ' '), ']'];
disp(['   Sigma:', result]);
fprintf('\n');

% Creating a compact string for Sigma_map
Sigma_map_compact = '';
keys = T.Sigma_map.keys;
for i = 1:length(keys)
    key = keys{i};
    value = T.Sigma_map(key); 
    Sigma_map_compact = [Sigma_map_compact, sprintf('%d ', value)];
end
Sigma_map_compact = ['[', Sigma_map_compact(1:end-1), ']'];
disp(['   Sigma_map: ', Sigma_map_compact]);
fprintf('\n');

disp('   Transition:');
disp(T.transitions)

disp(['   S0:', mat2str(T.S0)]);
fprintf('\n');

% Se esistono class_A e class_N, stampali al posto di SF
if isfield(T, 'class_A') && isfield(T, 'class_N')
    disp(['   class_A (accettanti): ', mat2str(T.class_A)]);
    disp(['   class_N (non accettanti): ', mat2str(T.class_N)]);
else
    % Altrimenti stampa SF se ancora presente
    if isfield(T, 'SF')
        SFcell = T.SF;
        strs = cellfun(@(v) ['[' strtrim(num2str(v)) ']'], SFcell, 'UniformOutput', false);
        finalStr = strjoin(strs, ', ');
        disp(['   SF: ', finalStr]);
    end
end

fprintf('\n');
end