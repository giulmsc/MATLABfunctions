

%% FUNCTION: id_DFA
%
% This function identifies (builds and visualizes) a **Deterministic Finite Automaton (DFA)**
% from a labeled set of accepted and rejected strings, provided in a `.l` file.
%
% INPUT:
% - file_name: String. Path to a `.l` file containing:
%     - `accepted_strings`: Cell array of strings that **must be accepted** by the DFA.
%     - `unaccepted_strings`: Cell array of strings that **must be rejected** by the DFA.
%     - `alphabet`: Cell array of input symbols used to build transitions.
%
% FUNCTIONALITY:
% 1. Reads the `.l` file using `readL`, which returns a structure with the fields:
%     - `.accepted_strings`
%     - `.unaccepted_strings`
%     - `.alphabet`
% 2. Builds a prefix-tree-like DFA structure using `build_automaton`, where:
%     - States are created along the input paths from accepted and unaccepted strings.
%     - Final states represent the accepted strings.
%     - Non-final states represent the rejected strings.
% 3. Displays the constructed automaton using `display_automaton`.
%
% OUTPUT:
% - None (visual feedback is printed or shown by `display_automaton`).
%
% EXAMPLE USAGE:
%   >> id_DFA('my_example.l');
%
% DEPENDENCIES:
% - `readL`            : Loads accepted/rejected strings and alphabet from file.
% - `build_automaton`  : Constructs the DFA using prefix expansion of strings.
% - `display_automaton`: Visualizes the resulting DFA (e.g., prints states and transitions).
%
% NOTE:
% - This function is especially useful in **automata inference**, **validation**, or 
%   **test-driven synthesis** scenarios.
% - You can extend it to export the automaton to a `.nfa` or visualize it as a graph.
%
function id_DFA(file_name)

L=readL(file_name);
automaton = build_automaton(L.accepted_strings, L.unaccepted_strings, L.alphabet);
display_automaton(automaton);
end