%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% FUNCTION: display_F
%
% This function prints the transition matrices used in the bisimulation 
% computation.
%
% INPUT:
% - F: A cell array where each entry F{j} is a transition matrix 
%      corresponding to a different symbol in the alphabet.
%
% FUNCTIONALITY:
% 1. Iterates through the cell array of transition matrices.
% 2. Displays each matrix with its dimensions for debugging and verification.
%
% NOTE:
% - This function is useful for checking how the transition matrices 
%   are structured before running the bisimulation refinement.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
function display_F(F)
    fprintf('Transition Matrix F:\n');
    for j = 1:length(F)
        [n, m] = size(F{j});
        fprintf('F{%d} (%dx%d):\n', j, n, m);
        for r = 1:n
            fprintf('[%s]\n', strjoin(string(F{j}(r,:)), ' '));
        end
        fprintf('\n');
    end
end