
function plot_automaton(dfa)
   
    keysList = keys(dfa.transitions);

    from = {};
    to = {};
    labels = {};

    for i = 1:length(keysList)
        k = keysList{i}; % es: 'x1_a'
        v = dfa.transitions(k); % stato di arrivo

        % Estrai stato di partenza e simbolo
        parts = strsplit(k, ' -- ');
        if length(parts) == 2
            from{end+1} = parts{1};
            to{end+1} = v;
            labels{end+1} = parts{2};
        end
    end

    % Assicura che tutti gli stati siano presenti
    all_nodes = unique([from, to, dfa.states]);

    % Crea grafo (senza pesi)
    G = digraph(from, to, [], all_nodes);

    % Disegna grafo
    figure;
    h = plot(G, 'Layout', 'layered', ...
        'EdgeLabel', labels, ...
        'NodeColor', 'k', ...
        'NodeLabelColor', 'w', ...
        'MarkerSize', 20);

    % Evidenzia lo stato iniziale (verde)
    if ismember(dfa.start, G.Nodes.Name)
        highlight(h, dfa.start, 'NodeColor', 'green');
    end

    % Evidenzia gli stati finali (rosso)
    for i = 1:length(dfa.final)
        if ismember(dfa.final{i}, G.Nodes.Name)
            highlight(h, dfa.final{i}, 'NodeColor', 'red');
        end
    end

    title('DFA Graph');
end