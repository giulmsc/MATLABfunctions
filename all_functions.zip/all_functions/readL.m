
function L=readL(file_name)
   % open the file 
   fileID = fopen(file_name, 'r');
    if fileID == -1
        error('cannot open the file: %s', file_name);
    end
    
    L=struct();
    L.alphabet={};
    L.accepted_strings={};
    L.unaccepted_strings={};

    while ~feof(fileID)
        line = strtrim(fgetl(fileID)); % Read one line and remove spaces
        % Skip blank lines or comments
        if isempty(line) || startsWith(line, '%')
            continue;
        end
        
        % save symbol on alphabet 
        if isempty(L.alphabet)
            L.alphabet=strsplit(line,',');
            continue;
        end 
        if isempty(L.accepted_strings)
            L.accepted_strings = strsplit(line, ',');
            continue;
        end

        if isempty(L.unaccepted_strings)
            L.unaccepted_strings = strsplit(line, ',');
            continue;
        end
    end 
    fclose(fileID);
    % view results
    fprintf('- Alphabet: %s\n', strjoin(L.alphabet, ', '));
    fprintf('- Acceptable strings: %s\n', strjoin(L.accepted_strings, ', '));
    fprintf('- Unacceptable strings: %s\n', strjoin(L.unaccepted_strings, ', '));

end
