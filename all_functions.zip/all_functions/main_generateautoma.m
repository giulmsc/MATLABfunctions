%% FUNCTION: main_generateautoma
%
% This function generates a **random incomplete DFA** and optionally introduces:
% - randomized or fixed alphabet
% - grouped final states (for generalized bisimulation)
% - behavioral equivalence between state pairs (for testing minimization)
%
% The resulting DFA is saved in `.nfa` format using `write_nfa`.
%
% INPUT:
% - N                  : Number of states in the DFA.
% - missing_prob       : Probability (0 ≤ p ≤ 1) of omitting a transition for each (state, symbol) pair.
% - grouped_finals     : Boolean flag. If 1, splits final states into `num_groups` sets for generalized analysis.
% - randomInitial      : Boolean flag. If 1, randomly chooses multiple initial states.
% - dynamic_alphabet   : Boolean flag. If 1, creates a variable-size alphabet based on N (up to 62 symbols).
%                        If 0, uses default fixed alphabet {'a','b','c','d','e'}.
% - enforce_equivalence: Boolean flag. If 1, introduces behavioral equivalence between random state pairs
%                        by making their outgoing transitions identical.
%
% FUNCTIONALITY:
% 1. Defines an alphabet:
%    - If `dynamic_alphabet` is true, uses a subset of letters, digits, uppercase (up to 62 symbols).
%    - Otherwise uses the fixed set {'a','b','c','d','e'}.
%
% 2. Calls `generate_random_DFA_incomplete` to create the incomplete automaton structure.
%    - Optionally initializes multiple initial states (`randomInitial`).
%
% 3. If `enforce_equivalence` is set, selects random pairs of states and **forces** them to behave equivalently
%    under the transition function, useful for testing bisimulation reduction.
%
% 4. Displays the generated initial and final states.
%
% 

function main_generateautoma(N, missing_prob, grouped_finals, randomInitial, dynamic_alphabet, enforce_equivalence)

    % 1.Calculate or set the Sigma alphabet
    if dynamic_alphabet
        
        num_symbols = max(5, min(round(sqrt(N)/2),62));
        base_alphabet = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
        Sigma = arrayfun(@(i) base_alphabet(i), 1:num_symbols, 'UniformOutput', false);
    else
        Sigma = {'a','b','c','d','e'};
    end

    % 2. Generates the random automaton
    DFA = generate_random_DFA_incomplete(N, Sigma, missing_prob,randomInitial);

    % 3. If required, force behavioural equivalences between certain pairs of states
    if enforce_equivalence
        max_pairs = floor(N / 2);
        num_pairs = randi([1, max_pairs]);% Number of random pairs
        perm = randperm(N);  % Random states to match
        for i = 1:num_pairs
            s1 = perm(2*i - 1);
            s2 = perm(2*i);
            DFA = force_equivalent_states(DFA, s1, s2);
        end
    end

    % 4.Show automaton information
    disp("Initial state:");
    disp(DFA.InitialState);

    disp("Final states:");
    disp(DFA.FinalStates);

    %disp("Transitions:");
    %keys = DFA.Transitions.keys;
    %for i = 1:length(keys)
    %    k = keys{i};
    %    v = DFA.Transitions(k);
    %    fprintf("δ(%s) = %d\n", k, v);
    %end

   % 5. Grouping of end states (dividendo solo gli stati finali)
num_groups = 3;
states = DFA.FinalStates;  % Prendi gli stati finali già esistenti

if grouped_finals && numel(states) >= num_groups
    % Suddivide gli stati finali in gruppi bilanciati
    group_size = floor(numel(states) / num_groups);
    final_groups = cell(1, num_groups);
    for i = 1:num_groups
        start_idx = (i-1)*group_size + 1;
        if i == num_groups
            final_groups{i} = states(start_idx:end);  % ultimo gruppo prende tutto il resto
        else
            final_groups{i} = states(start_idx:start_idx+group_size-1);
        end
    end
    DFA.FinalStates = final_groups;

    disp('Final states grouped (numeric):');
    disp(DFA.FinalStates);

else
    % Se non ci sono abbastanza stati per fare i gruppi, lascia tutto come un gruppo unico
    %warning('Impossibile suddividere in %d gruppi. Stati finali mantenuti non raggruppati.', num_groups);
    DFA.FinalStates = states;
end

    % 6. Writing to file
    DFAout = convert_to_write_format(DFA);
    
    write_nfa('G5.nfa', DFAout, grouped_finals);
  

end