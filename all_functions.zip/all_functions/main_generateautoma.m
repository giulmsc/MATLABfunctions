
%% FUNCTION: main_generateautoma
%
% This function generates a **random incomplete DFA**, displays its structure,
% optionally groups the final states into sets (for generalized bisimulation), 
% and saves the result to file in `.nfa` format using `write_nfa`.
%
% INPUT:
% - N               : Integer. Number of states in the generated DFA.
% - missing_prob    : Float in [0, 1]. Probability of **omitting a transition** 
%                     for each (state, symbol) pair.
% - grouped_finals  : Boolean (0 or 1). 
%                     - If `1`, the set of final states is **divided into groups** 
%                       (as required by generalized bisimulation).
%                     - If `0`, all final states are treated as a flat set.
%
% FUNCTIONALITY:
% 1. Defines an alphabet `Sigma = {'a','b','c','d','e'}`.
% 2. Generates a random incomplete DFA using `generate_random_DFA_incomplete(...)`.
% 3. Displays:
%     - Initial state(s)
%     - Final states
%     - Transitions in the form δ(state,symbol) = destination
% 4. If `grouped_finals == 1`, splits the final states into multiple sets (`num_groups = 4`)
%    and updates `DFA.FinalStates` accordingly.
% 5. Converts the internal DFA format to a structure compatible with `write_nfa` via `convert_to_write_format`.
% 6. Writes the automaton to file `'G5.nfa'` with `write_nfa`.
%
% EXAMPLE USAGE:
%   >> main_generateautoma(6, 0.3, 1);
%
% NOTES:
% - The output `.nfa` file can be directly used as input for bisimulation algorithms.
% - Useful for generating varied test cases for automata reduction or abstraction.
% - The file name (`G5.nfa`) is currently fixed; you can easily extend this to accept a filename argument.
%
% DEPENDENCIES:
% - generate_random_DFA_incomplete
% - convert_to_write_format
% - write_nfa
%
function main_generateautoma(N,missing_prob,grouped_finals)

%define an alphabet sigma to create transitions of automata 

Sigma={'a','b','c','d','e'};

DFA=generate_random_DFA_incomplete(N,Sigma,missing_prob);

% 2. Show info
disp("Initial state:");
disp(DFA.InitialState);

disp("Final states:");
disp(DFA.FinalStates);

disp("Transitions:");

keys = DFA.Transitions.keys;
for i = 1:length(keys)
    k = keys{i};
    v = DFA.Transitions(k);
    fprintf("δ(%s) = %d\n", k, v);
end

% 3. Build the final groups
% Define how many sets of final states there must be
num_groups = 4;
states = randperm(N);

if grouped_finals == 1
    group_size = floor(N / num_groups);
    final_groups = cell(1, num_groups);

    for i = 1:num_groups
        start_idx = (i-1)*group_size + 1;
        if i == num_groups
            final_groups{i} = states(start_idx:end);
        else
            final_groups{i} = states(start_idx:start_idx+group_size-1);
        end
    end
    DFA.FinalStates = final_groups;  % update DFA, not DFAout
else
    DFA.FinalStates = states;
end

% 4. Convert and save
DFAout = convert_to_write_format(DFA);
write_nfa('G5.nfa', DFAout, grouped_finals);

end