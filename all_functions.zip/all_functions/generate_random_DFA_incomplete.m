
%% FUNCTION: generate_random_DFA_incomplete
%
% This function generates a **random, possibly incomplete Deterministic Finite Automaton (DFA)**.
% It is useful for testing algorithms that handle nondeterminism, partial transitions, or 
% model synthesis tasks.
%
% INPUT:
% - N             : Number of states (positive integer).
% - Sigma         : Cell array of symbols (e.g., `{'a','b'}`) representing the input alphabet.
% - missing_prob  : Probability (0 ≤ p ≤ 1) of **omitting** a transition for a given (state, symbol) pair.
%                   - A value of 0 creates a complete DFA.
%                   - A value near 1 creates highly sparse/incomplete transition relations.
%
% OUTPUT:
% - DFA: A structure representing the generated automaton, with fields:
%     - .States        : Vector `[1, 2, ..., N]`
%     - .Alphabet      : Copy of the input `Sigma`
%     - .InitialState  : Random subset of states (can include multiple initial states)
%     - .FinalStates   : Random subset of states (can include multiple final states)
%     - .Transitions   : A `containers.Map` from keys `'state,symbol'` → numeric destination state
%
% FUNCTIONALITY:
% 1. Generates a list of N states.
% 2. Randomly selects:
%     - A subset of states as initial states (`DFA.InitialState`)
%     - A subset of states as final states (`DFA.FinalStates`)
% 3. Iterates through each `(state, symbol)` pair:
%     - With probability `1 - missing_prob`, a destination state is selected randomly and added as a transition.
%     - Otherwise, no transition is added (incomplete transition).
%
% TRANSITION FORMAT:
% - Keys in the `DFA.Transitions` map follow the format: `'s,a'`, where:
%     - `s` is the source state (integer)
%     - `a` is the input symbol (string from `Sigma`)
% - The values are numeric destination states.
%
% EXAMPLE:
%   >> DFA = generate_random_DFA_incomplete(5, {'a','b'}, 0.3);
%   >> keys(DFA.Transitions)
%   ans = {'1,a', '1,b', '2,a', '3,b', ...}
%
% NOTE:
% - The automaton may have **multiple initial states** (unlike classical DFA).
% - The result is not guaranteed to be complete or connected.
% - Designed for experimentation with bisimulation, reduction, or synthesis methods.
%
function DFA = generate_random_DFA_incomplete(N, Sigma, missing_prob, randomInitial)
% generate_random_DFA_incomplete generates an incomplete DFA
% INPUT:
% N - number of states
% Sigma - cell array of symbols, e.g. {'a','b'}
% missing_prob - probability of NOT having a transition (0 ≤ p ≤ 1)
% OUTPUT:
% DFA - structure with:
% .States, .Alphabet, .InitialState, .FinalStates, .Transitions (containers.Map)

    DFA.States = 1:N;
    DFA.Alphabet = Sigma;
    
    if randomInitial
        numInitial=randi([1,round(sqrt(N))]);
        perm=randperm(N);
        DFA.InitialState = sort(perm(1:numInitial));
    else 
        DFA.InitialState = randi(N);
    end
    
    
    numFinal = randi([3,round(sqrt(N))]);
    perm = randperm(N);
    DFA.FinalStates = sort(perm(1:numFinal));

    DFA.Transitions = containers.Map();

    for s = 1:N
        for i = 1:length(Sigma)
            a = Sigma{i};
            if rand > missing_prob  % Only with some probability is the transition created
                dest = randi(N);
                key = sprintf('%d,%s', s, a);
                DFA.Transitions(key) = dest;
            end
        end
    end
end