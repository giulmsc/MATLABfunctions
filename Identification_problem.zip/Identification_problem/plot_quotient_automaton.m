function plot_quotient_automaton(Tq)
% Visualizza l'automa quoziente Tq con nodi bianchi e label A/N interne, pi_i esterne

n = length(Tq.S);
edges = Tq.transitions;
sources = edges(:, 1);
targets = edges(:, 3);
labels = Tq.Sigma(edges(:, 2));

% Crea il grafo
G = digraph(sources, targets);

% Etichette interne: A, N o vuoto
internal_labels = strings(1, n);
if isfield(Tq, 'class_A')
    internal_labels(Tq.class_A) = "A";
end
if isfield(Tq, 'class_N')
    internal_labels(Tq.class_N) = "N";
end

% External labels
external_labels = arrayfun(@(i) ['\pi_', num2str(i)], 1:n, 'UniformOutput', false);

% Plot
figure;
h2 = plot(G, 'Layout', 'subspace', ...
    'NodeLabel', {}, ...
    'EdgeLabel', {}, ...
    'NodeColor', [0 0 0], ...
    'MarkerSize', 43, ...
    'LineWidth', 1.5, ...
    'NodeFontSize', 1);
hold on;
h1 = plot(G, 'Layout', 'subspace', ...
    'NodeLabel', internal_labels, ...
    'EdgeLabel', labels, ...
    'EdgeColor', [0 0 0], ...
    'EdgeFontSize', 15, ...
    'NodeColor', 'w', ...
    'MarkerSize', 40, ...
    'LineWidth', 1.5, ...
    'NodeFontSize', 15);

h.NodeColor = [0.8, 0.8, 0.8];  

% External labels 
hold on;
x_pos = get(h1, 'XData');
y_pos = get(h1, 'YData');

for i = 1:n
    text(x_pos(i) + 0.3, y_pos(i), external_labels{i}, ...
        'FontSize', 15, 'Color', [0 0 0], 'Interpreter', 'tex');
end

% Evidenzia stati iniziali con bordo nero spesso
if isfield(Tq, 'S0')
    highlight(h1, Tq.S0, 'LineWidth',20 ,'EdgeColor','black');
end

title('Quotient Automaton', 'FontWeight', 'bold');
axis off;
end