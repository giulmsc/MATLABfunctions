function partitions = binaryMatrixToCellPartitions(P)
% P è una matrice binaria di dimensione (num_partitions x num_states)
% Restituisce una struct con campi: pi_1, pi_2, ..., pi_n
% Ogni campo contiene il vettore degli stati appartenenti a quella partizione

    num_partitions = size(P, 1);
    partitions = struct();

    for i = 1:num_partitions
        partition_name = ['pi_' num2str(i)];
        partitions.(partition_name) = find(P(i, :) == 1)-1;
    end
end