%% FUNCTION: id_DFA_bisimulation
%
% Identifies and analyzes a **minimal bisimulation** for a DFA inferred from 
% accepted and rejected strings, optionally exploring **all valid classifications**
% of intermediate states into accepted/non-accepted classes.
%
% INPUT:
% - file_name          : Name of the `.l` file containing:
%                        * accepted strings,
%                        * rejected strings,
%                        * alphabet used for transitions.
% - use_allcombinatios : Boolean flag (0 or 1). If set to 1, the function explores 
%                        **all possible class assignments** (accepted/rejected) for intermediate states.
% - verbose            : Boolean flag (0 or 1). If set to 1, prints detailed logs of:
%                        * current classification,
%                        * resulting partitions,
%                        * quotient automata structure.
%
% FUNCTIONALITY:
% 1. Reads a set of labeled strings and alphabet using `readL`.
% 2. Constructs a prefix-tree DFA using `build_automaton`.
% 3. If `use_allcombinatios == 1`:
%    - Generates all possible combinations of classifications (`class_combinations`).
%    - For each combination:
%        - Builds the structured DFA and its STS.
%        - Runs generalized bisimulation (`generalized_bisimulation_standard_algorithm`).
%        - Saves each unique partition (tracked using a hashed string representation).
%        - Keeps track of the best (minimal) partition found.
%    - After iteration, prints:
%        - The best classification and resulting quotient automaton.
%        - Summary of all distinct partitions encountered and their frequencies.
% 4. If `use_allcombinatios == 0`:
%    - Builds a basic DFA and STS using only prefix information.
%    - Computes generalized bisimulation using the default classification.
%
% OUTPUT:
% - None returned directly. Displays:
%    - Automaton structure
%    - Final partitions
%    - Best quotient automaton
%    - Plot (if enabled via `plot_quotient_automaton`)
%
% DEPENDENCIES:
% - `readL`, `build_automaton`, `build_structured_G`, `STS_fromG`
% - `generalized_bisimulation_standard_algorithm`, `quotientSTS_withclass`
% - `plot_quotient_automaton`, `display_Pi`, `printSTSq`
% - Helper: `partition_to_string`, `pretty_partition`
%
% EXAMPLE USAGE:
%   >> id_DFA_bisimulation('sample.l', 1, 1);
%
% NOTE:
% - This function is powerful for automaton **inference** and **analysis** when the true 
%   classification of intermediate states is unknown or ambiguous.
% - It is especially useful in formal methods, fault detection, and system abstraction contexts.
%

function id_DFA_bisimulation(file_name,use_allcombinatios,verbose)

L=readL(file_name);
automaton = build_automaton(L.accepted_strings, L.unaccepted_strings, L.alphabet);
display_automaton(automaton);

    if use_allcombinatios == 1
        all_combinations = class_combinations(automaton);

        best_Pi = [];
        min_blocks = inf;
        all_Pi = {};
        all_in_Pi={};
        all_classes = {};

        partition_counts = containers.Map();
        
        for i = 1:length(all_combinations)
            classes = all_combinations(i);

            if verbose
                fprintf('\n Iteration %d \n', i);
                fprintf('Class A: %s\n', strjoin(classes.accepted, ', '));
                fprintf('Class N: %s\n', strjoin(classes.notaccepted, ', '));
            end

           % Construction G and STS
            G = build_structured_G(automaton, L.alphabet, use_allcombinatios, classes);
            T = STS_fromG(G, 0);

            
            [Pi_sim,initial_pi] = generalized_bisimulation_standard_algorithm(T, 0);
            Tq=quotientSTS_withclass(T,Pi_sim,classes);
            if verbose
                display_Pi(Pi_sim,initial_pi);
            end
            if verbose 
                fprintf('\n Quotient automaton for partition found at iteration %d\n',i);
                printSTSq(Tq);
            end
            Pi_str = partition_to_string(Pi_sim);

            % Global partition counts
            if isKey(partition_counts, Pi_str)
                partition_counts(Pi_str) = partition_counts(Pi_str) + 1;
            else
                partition_counts(Pi_str) = 1;
                all_Pi{end+1} = Pi_sim;
                all_classes{end+1} = classes;
            end

            % Update the global best
            if length(Pi_sim) < min_blocks
                min_blocks = length(Pi_sim);
                best_Pi = Pi_sim;
                best_iter = i;
                best_class = all_classes{best_iter};
            end

            
        end

        % Final Summary
        fprintf('\n==============================\n');
        fprintf('Best partition found at iteration %d with %d blocks. Obtained with class:\n', best_iter, min_blocks);
        fprintf('\nClass A: %s\n', strjoin(best_class.accepted, ', '));
        fprintf('Class N: %s\n', strjoin(best_class.notaccepted, ', '));
        displayPI(best_Pi);

        best_Tq=quotientSTS_withclass(T,best_Pi,best_class);
        printSTSq(best_Tq);
        plot_quotient_automaton(best_Tq);

        % Summary of distinct partitions
        if verbose
            fprintf('\n==============================\n');
            fprintf('Summary of distinct partitions found:\n');
            
            keys_list = keys(partition_counts);
            for i = 1:length(keys_list)
                key = keys_list{i};
                count = partition_counts(key);
            
                fprintf('\nPartition %d (appeared %d times):\n', i, count);
                Pi_blocks = all_Pi{i};
            
                for j = 1:length(Pi_blocks)
                    block = Pi_blocks{j};
                    fprintf('   pi_%d: %s\n', j, mat2str(block));
                end
            end
        end
    else
        % Simple case: no A/N classification
        classes = [];
        G = build_structured_G(automaton, L.alphabet, use_allcombinatios, classes);
        T = STS_fromG(G, 1);
        [Pi_sim,initial_pi] = generalized_bisimulation_standard_algorithm(T, 0);
        display_Pi(Pi_sim,initial_pi);
    end
end

% Helper function
function out = partition_to_string(Pi)
    Pi_sorted = cellfun(@(x) sort(x), Pi, 'UniformOutput', false);
    Pi_strs = cellfun(@(x) strjoin(string(x), '-'), Pi_sorted, 'UniformOutput', false);
    Pi_strs = cellfun(@char, Pi_strs, 'UniformOutput', false);
    Pi_strs = sort(Pi_strs);
    out = strjoin(Pi_strs, '|');
end

function pretty_str = pretty_partition(Pi)
    block_strs = cell(size(Pi));
    for i = 1:length(Pi)
        block = Pi{i};  %
        block_strs{i} = ['{' strjoin(arrayfun(@num2str, block, 'UniformOutput', false), ', ') '}'];
    end
    pretty_str = ['{', strjoin(block_strs, ', '), '}'];
end