%% FUNCTION: build_automaton
%
% This function builds a deterministic finite automaton (DFA) from two sets 
% of input strings: one set of **accepted** strings and one of **not accepted** 
% strings. It ensures that accepted strings lead to final states, and not 
% accepted strings lead to non-final states.
%
% INPUT:
% - accepted:      A cell array of strings (each string is a sequence of symbols) 
%                  that must be accepted by the automaton.
% - not_accepted:  A cell array of strings that must be rejected (lead to non-final states).
% - alphabet:      A cell array or character array containing all symbols in the alphabet.
%                  (Note: currently not directly used, but assumed to define valid inputs.)
%
% OUTPUT:
% - automaton: A structure containing the generated automaton:
%     - automaton.states           : Cell array of all state names ('x0', 'x1', ..., sorted).
%     - automaton.start            : Initial state (always `'x0'`).
%     - automaton.final            : Set of final states (those reached by accepted strings).
%     - automaton.transitions      : A `containers.Map` representing the transition function.
%                                   Keys are formatted as `'xi -- a'` and values are target states.
%     - automaton.accepted_class   : Set of states reached at the end of accepted strings.
%     - automaton.notaccepted_class: Set of states reached at the end of not accepted strings.
%
% FUNCTIONALITY:
% 1. Starts from initial state `'x0'`.
% 2. For each string (accepted or not), builds a path of transitions:
%    - Each unique prefix generates a new state.
%    - Transitions are added only when not already existing.
%    - Transitions are deterministic.
% 3. Marks end states of accepted strings as **final**.
% 4. Records and sorts the sets of states reached by accepted and not accepted strings.
% 5. All states and final states are sorted numerically (e.g., 'x2' < 'x10').
%
% INTERNAL:
% - Uses a nested function `build_path` to build a transition path for each string.
% - Ensures uniqueness and ordering of states and final states.
%
% APPLICATION:
% - Useful for automatically generating a DFA from examples (positive and negative).
% - Serves as a preprocessing step for automaton analysis, minimization, or bisimulation.
%
% EXAMPLE:
%   accepted     = {'ab', 'ac'};
%   not_accepted = {'aa', 'b'};
%   build_automaton(accepted, not_accepted, {'a', 'b', 'c'});
%
% NOTE:
% - State names are strings in the form `'xN'`, where N is a numeric index.
% - The alphabet input is currently unused in the function logic but can be
%   useful for validation or extension.
%


function automaton = build_automaton(accepted, not_accepted, alphabet)
    automaton.states = {};
    automaton.start = 'x0';
    automaton.final = {};
    automaton.transitions = containers.Map();
    automaton.accepted_class={};
    automaton.notaccepted_class={};
    state_counter = 0;

    automaton.states{end+1} = 'x0';

    % Internal function to build a path and return the last state
    function last_state = build_path(str)
        current_state = 'x0';
        for j = 1:length(str)
            prefix = str(j);
            key = [current_state, ' -- ', prefix];
            if ~isKey(automaton.transitions, key)
                state_counter = state_counter + 1;
                new_state = ['x', num2str(state_counter)];
                automaton.states{end+1} = new_state;
                automaton.transitions(key) = new_state;
            end
            current_state = automaton.transitions(key);
        end
        last_state = current_state;
    end

    % Construction of path from unaccepted strings (NOT final states)
    for i = 1:length(not_accepted)
        not_accetped_state=build_path(not_accepted{i});
        automaton.notaccepted_class{end+1}=not_accetped_state;
    end
    automaton.notaccepted_class = unique(automaton.notaccepted_class);
    nums = cellfun(@(s) str2double(s(2:end)), automaton.notaccepted_class);
    [~, idx] = sort(nums);
    automaton.notaccepted_class = automaton.notaccepted_class(idx);
    % Construction of paths from accepted strings (final states)
    for i = 1:length(accepted)
        final_state = build_path(accepted{i});
        automaton.final{end+1} = final_state;
        automaton.accepted_class{end+1}=final_state;
    end
    automaton.accepted_class = unique(automaton.accepted_class);
    nums = cellfun(@(s) str2double(s(2:end)), automaton.accepted_class);
    [~, idx] = sort(nums);
    automaton.accepted_class = automaton.accepted_class(idx);
   
    %Remove duplicates and sort numerically
    automaton.final = unique(automaton.final);
    final_nums = cellfun(@(s) str2double(s(2:end)), automaton.final);
    [~, sort_idx] = sort(final_nums);
    automaton.final = automaton.final(sort_idx);

    unique_states = unique(automaton.states);
    % Extract the number from each state, e.g. from 'x12' you get 12
    state_nums = cellfun(@(s) str2double(s(2:end)), unique_states);
    % Sort by these numbers
    [~, sort_idx] = sort(state_nums);
    automaton.states = unique_states(sort_idx);
    

end