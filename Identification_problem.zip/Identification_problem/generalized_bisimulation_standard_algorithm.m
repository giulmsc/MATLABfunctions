%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% FUNCTION: generalized_bisimulation_standard_algorithm
%
% This function computes the minimal bisimulation partition of a given 
% automaton represented as a State Transition System (STS), using a 
% generalized **standard set-based algorithm**. Unlike the basic version, 
% it supports multiple final state sets (T.SF come cell array) and 
% processes the input symbols via their mapped indices.
%
% INPUT:
% - T: A structure representing the State Transition System (STS), typically 
%      obtained via `STS(filename)`. It must contain:
%     - T.S        : Vector of all states.
%     - T.Sigma    : Cell array or vector of input symbols.
%     - T.Sigma_map: containers.Map associating each symbol to its numeric index.
%     - T.S0       : Vector of initial states.
%     - T.SF       : Cell array of final state subsets {SF₁, SF₂, ..., SFₙ}.
%     - T.transitions: Matrix of transitions in the form [source, symbol_idx, target].
%
% - all_process:
%     - 0 → silent execution (no intermediate output),
%     - 1 → verbose output: shows each step of the refinement process,
%     - 2 → debug output: shows full internal reasoning (partitions, splits, symbols).
%
% OUTPUT:
% - PI_sim     : Final partition of the state space as a cell array.
%                Each cell contains a subset of states that are bisimilar.
% - initial_Pi : Initial partition before refinement, based on the classification
%                of initial and final states.
%
% FUNCTIONALITY:
% 1. **Initial Partitioning**:
%    - {S₀ \ (⋃ SF)}: Initial but non-final states,
%    - {SFᵢ \ S₀}    : Final but non-initial states for each subset SFᵢ,
%    - {S₀ ∩ SFᵢ}    : States both initial and final,
%    - {S \ (S₀ ∪ SF)}: All other states.
%
% 2. **Refinement Loop**:
%    - Iterates through each current partition (π_target).
%    - For each input symbol σ:
%       - Computes the predecessor states of π_target under σ.
%       - Checks for partial intersection with other partitions (π_check).
%       - If partial overlap is found, π_check is split into two partitions.
%    - The refinement continues until no further changes occur (fixed point).
%
% 3. **Result**:
%    - The final partition PI_sim groups all states that are indistinguishable 
%      in terms of their future behaviors — i.e., they are bisimilar.
%
% FEATURES:
% - Handles **multiple final state sets**.
% - Uses **symbol-to-index mapping** for compatibility with symbolic inputs.
% - Provides **optional tracing** of the refinement process for educational, 
%   analytical, or debugging purposes.
%
% DEPENDENCIES:
% - `get_predecessors(transitions, pi_target, sigma_index)`: a utility function 
%   that returns the set of predecessors of a given set under a symbol.
% - `union_all(cell_array)`: computes the union of elements in a cell array.
%
% NOTE:
% - The function assumes all state indices in T.S are numeric and contiguous.
% - Predecessors are computed using symbol indices obtained via T.Sigma_map.
%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

function [PI_sim,initial_Pi] = generalized_bisimulation_standard_algorithm(T, all_process)
  % INPUT:
    % - A STS T: 
    % T.S0: initial states
    % T.SF: final states
    % T.S: set of all states
    

    % Step 1: Partition initialisation
    PI = {};

    % Step 2: Addition of S0 \ SF to the partition
    
    if ~isempty(setdiff(T.S0, union_all(T.SF)))
        PI{end+1} = setdiff(T.S0, union_all(T.SF));
    end

    % Step 3: Iteration on final sets SF_i
    for i = 1:length(T.SF)
     
        if ~isempty(intersect(T.S0, T.SF{i}))
            PI{end+1} = intersect(T.S0, T.SF{i});
        end

        if ~isempty(setdiff(T.SF{i}, T.S0))
           PI{end+1} = setdiff(T.SF{i}, T.S0);
        end
    end

    % Step 4: Addition of S \ (S0 ∪ SF) to the partition
    %for i = 1:length(T.SF)
     %   PI{end+1}=T.SF{i};
    %end
    
    if ~isempty(setdiff(T.S, union(T.S0, union_all(T.SF))))
        PI{end+1} = setdiff(T.S, union(T.S0, union_all(T.SF)));
    end
    
    initial_Pi=PI;
    
  changed = true;
while changed
    changed = false;

    for pi_target_idx = 1:length(PI)
        pi_target = PI{pi_target_idx};

        if all_process == 2
            fprintf('\n====================================\n');
            fprintf('Analysis of the pi_target class_%d: %s\n', pi_target_idx, mat2str(pi_target));
        end

        values_Sigma = values(T.Sigma_map);

        for i = 1:length(values_Sigma)
            sigma = values_Sigma{i};

            if all_process == 2
                if iscell(T.Sigma)
                    symbol = T.Sigma{sigma};
                else
                    symbol = T.Sigma(sigma);
                end
                fprintf('\n  - Symbol σ = ''%s''\n', symbol);
            end

            pre_sigma = get_predecessors(T.transitions, pi_target, sigma);

            if all_process == 2
                if isempty(pre_sigma)
                    fprintf('    Predecessors (pre_σ(pi_target)): ∅\n');
                else
                    fprintf('    Predecessors (pre_σ(pi_target)): %s\n', mat2str(pre_sigma));
                end
            end

            for pi_check_idx = 1:length(PI)
                pi_check = PI{pi_check_idx};
                inter = intersect(pi_check, pre_sigma);

                if all_process == 2
                    fprintf('    > Control over pi_%d: %s\n', pi_check_idx, mat2str(pi_check));
                    if isempty(inter)
                        fprintf('      ↳ No intersection\n');
                    else
                        fprintf('      ↳ Intersection: %s\n', mat2str(inter));
                    end
                end

                if ~isempty(inter) && ~isequal(inter, pi_check)
                    diff = setdiff(pi_check, inter);

                    PI{pi_check_idx} = inter;
                    
                    PI{end+1} = diff;

                    changed = true;

                    if all_process==1
                        fprintf('\n pi_target class_%d: %s\n', pi_target_idx, mat2str(pi_target));
                        fprintf('\n  - Symbol σ = ''%s''\n', T.Sigma{sigma});
                        fprintf('    Predecessors (pre_σ(pi_target)): %s\n', mat2str(pre_sigma));
                        fprintf('\n      Split executed on the pi_%d\n', pi_check_idx);
                        fprintf('    >  pi_%d: %s\n', pi_check_idx, mat2str(pi_check));
                        fprintf('        New pi_%d: %s\n', pi_check_idx, mat2str(inter));
                        fprintf('        New pi_%d: %s\n', length(PI), mat2str(diff));
                        fprintf('\n    Updated partitions:\n');
                        for k = 1:length(PI)
                            fprintf('        pi_%d: %s\n', k, mat2str(PI{k}));
                        end
                    end 

                    if all_process == 2
                       
                        fprintf('\n      Split performed on pi_%d\n', pi_check_idx);
                        fprintf('        New pi_%d: %s\n', pi_check_idx, mat2str(inter));
                        fprintf('        New pi_%d: %s\n', length(PI), mat2str(diff));
                        fprintf('    Updated partitions:\n');
                        for k = 1:length(PI)
                            fprintf('        pi_%d: %s\n', k, mat2str(PI{k}));
                        end
                    end

                    break;  % restarts with updated partition
                end
            end

            if changed
                break;
            end
        end

        if changed
            break;
        end
    end
end
    % Step 6: Return of the resulting partition
    PI_sim = PI;
end

%% FUNCTION: union_all
%
% This function computes the union of all elements in a given cell array.
% It is used to handle multiple subsets of final states in bisimulation calculations.
%
% INPUT:
% - cell_array: A cell array where each element is a numeric vector of states.
%
% OUTPUT:
% - result: A numeric vector containing the union of all elements in cell_array.
%
% FUNCTIONALITY:
% 1. If the input is not a cell array, it is converted into one.
% 2. Iterates over all elements in the cell array and computes their union.
% 3. Returns a numeric vector representing the union of all elements.
%
function result = union_all(cell_array)
    result = [];
    if ~iscell(cell_array)
        cell_array = {cell_array}; % Convert to cell array if necessary
    end
    for i = 1:length(cell_array)
        result = union(result, cell_array{i});
    end
end