
%% FUNCTION: display_single_partition
%
% This function prints a single partition in a human-readable format, accepting either:
% - a `struct` where each field represents a partition block (e.g., `pi_1`, `pi_2`, ...), or
% - a `cell array` where each cell contains a vector of state indices.
%
% INPUT:
% - P: A partition of states, in one of the following formats:
%     1. **struct**: with named fields like `pi_1`, `pi_2`, etc., where each field is a vector of state indices.
%     2. **cell array**: where `P{i}` contains a vector of states in the i-th block.
%
% OUTPUT:
% - (none): The function directly prints to the command window using `fprintf`.
%
% FORMATTING:
% - For structs: prints `    pi_k: [a b c]` using the field name.
% - For cell arrays: prints `    pi_k: [a b c]` using the index.
%
% FUNCTIONALITY:
% 1. Detects the format of the input (`struct` or `cell`).
% 2. Iterates over each partition block and displays its contents using `mat2str`.
% 3. If the format is not supported, an error is raised.
%
% EXAMPLE (struct input):
%   P = struct('pi_1', [0 1], 'pi_2', [2 3]);
%   display_single_partition(P);
%   Output:
%       pi_1: [0 1]
%       pi_2: [2 3]
%
% EXAMPLE (cell input):
%   P = {[0 1], [2 3]};
%   display_single_partition(P);
%   Output:
%       pi_1: [0 1]
%       pi_2: [2 3]
%
% NOTE:
% - This function is particularly useful for debugging and displaying results from 
%   bisimulation or state partitioning algorithms.
% - The formatting assumes that partitions contain **numeric** vectors.
%

function display_Pi(Pi, Pi_initial)
    fprintf('\nInitial partition:\n');
    display_single_partition(Pi_initial);

    fprintf('\nFinal partition:\n');
    display_single_partition(Pi);
end

function display_single_partition(P)
    if isstruct(P)
        fn = fieldnames(P);
        for i = 1:length(fn)
            fprintf('    %s: %s\n', fn{i}, mat2str(P.(fn{i})));
        end
    elseif iscell(P)
        for i = 1:length(P)
            fprintf('    pi_%d: %s\n', i, mat2str(P{i}));
        end
    else
        error('Unsupported partition format: expected struct or cell array.');
    end
end