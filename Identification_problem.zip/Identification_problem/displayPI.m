
function displayPI(partitions)
    
    % View structure with partitions
    
    fprintf('\n');
    disp('Final partitions:');
    display_single_partition(partitions)
end

function display_single_partition(P)
    if isstruct(P)
        fn = fieldnames(P);
        for i = 1:length(fn)
            fprintf('    %s: %s\n', fn{i}, mat2str(P.(fn{i})));
        end
    elseif iscell(P)
        for i = 1:length(P)
            fprintf('    pi_%d: %s\n', i, mat2str(P{i}));
        end
    else
        error('Unsupported partition format: expected struct or cell array.');
    end
end